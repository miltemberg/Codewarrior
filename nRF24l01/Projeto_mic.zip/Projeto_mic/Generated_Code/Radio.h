/**
 * \file
 * \brief This is the interface to the Nordic Semiconductor nRF24L01+
 * \author (c) 2013-2014 Erich Styger, http://mcuoneclipse.com/
 * \note MIT License (http://opensource.org/licenses/mit-license.html), see 'RNet_License.txt'
 *
 * This module deals with the low level interface of the transceiver.
 */

#ifndef RADIO_H_
#define RADIO_H_

#include "RNetConf.h"


/*!
 * \brief Set the radio communication channel
 * \param channel New channel number.
 * \return Error code, ERR_OK if everything is fine.
 */
uint8_t RADIO_SetChannel(uint8_t channel);

/*! 
 * \brief Radio power-on initialization.
 * \return Error code, ERR_OK if everything is ok.
 */
uint8_t RADIO_PowerUp(void);

/*! 
 * \brief Function to determine if we could power down the radio.
 * \return TRUE if there is no transmission pending so we can power down the radio.
 */
bool RADIO_CanDoPowerDown(void);

/*! 
 * \brief Power down the radio.
 * \return Error code, ERR_OK if everything is ok.
 */
uint8_t RADIO_PowerDown(void);

/*!
 * \brief Processes the radio state machine. Needs to be called frequently from the application (about every 10 ms).
 * \return Error code, ERR_OK for no failure.
 */
uint8_t RADIO_Process(void);

/*! \brief Radio transceiver initialization */
void RADIO_Init(void);

/*! \brief Radio transceiver de-initialization */
void RADIO_Deinit(void);

#endif /* RADIO_H_ */

