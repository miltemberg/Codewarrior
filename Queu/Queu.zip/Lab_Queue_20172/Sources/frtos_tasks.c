
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/

/* Begin of <includes> initialization, DO NOT MODIFY LINES BELOW */

#include "TSK1.h"
#include "FRTOS1.h"
#include "frtos_tasks.h"

/* End <includes> initialization, DO NOT MODIFY LINES ABOVE */
#include "LED_Blue.h"
#include "LED_Green.h"
#include "LED_Red.h"
#include "console_io.h"

QueueHandle_t fila;



static portTASK_FUNCTION(InsereNaFilaTask, pvParameters) {

  /* Write your task initialization code here ... */
    TickType_t xPrimeiroTick;
    int   lValorAEnviar;
    BaseType_t xStatus;
    const int delay = 500/portTICK_RATE_MS;// delay de 500ms

    xPrimeiroTick = xTaskGetTickCount();
    lValorAEnviar = (int)pvParameters;

    for(;;)
    {
    	LED_Blue_NegVal(NULL);
	    xStatus =FRTOS1_xQueueSendToBack(fila,&lValorAEnviar, 0);  // Coloca na fila o valor a enviar sem espera (deadline = 0)
	    if (xStatus != pdPASS){
	        printf("Nao rolou inserir na fila...\n");
	    }
        FRTOS1_vTaskDelayUntil(&xPrimeiroTick, delay);
    }
  vTaskDelete(InsereNaFilaTask);
}

static portTASK_FUNCTION(RetiraDaFilaTask, pvParameters) {

  /* Write your task initialization code here ... */
    int   valorAReceber;
    BaseType_t xStatus;
    const int delay = 700/portTICK_RATE_MS;

    for(;;)
    {
	    LED_Red_NegVal(NULL);
	    
        FRTOS1_vTaskDelay(delay);
        
	    if (FRTOS1_uxQueueMessagesWaiting(fila) != 0) {
	        printf("Tem item na fila:%i\n",valorAReceber);
	    }
	    xStatus =FRTOS1_xQueueReceive(fila, &valorAReceber, delay);

	    if (xStatus == pdPASS){
	        printf("Recebeu: %i\n", valorAReceber);
	    }
	    else {
	        printf("N�o conseguiu receber da fila\n");

	    }
    }
  /* Destroy the task */
  vTaskDelete(RetiraDaFilaTask);
}

void CreateTasks(void) {
	
	fila = FRTOS1_xQueueCreate(5,sizeof(int));// 5 lugares na fila e em cada lugar colocasse um inteiro
	
  if (FRTOS1_xTaskCreate(
     InsereNaFilaTask,  /* pointer to the task */
      "Ins100", /* task name for kernel awareness debugging */
      configMINIMAL_STACK_SIZE + 0, /* task stack size */
      (void*)100, /* optional task startup argument */
      tskIDLE_PRIORITY + 1,  /* initial priority */
      (xTaskHandle*)NULL /* optional task handle to create */
    ) != pdPASS) {
      /*lint -e527 */
      for(;;){}; /* error! probably out of memory */
      /*lint +e527 */
  }
  if (FRTOS1_xTaskCreate(
     InsereNaFilaTask,  /* pointer to the task */
      "Ins200", /* task name for kernel awareness debugging */
      configMINIMAL_STACK_SIZE + 0, /* task stack size */
      (void*)200, /* optional task startup argument */
      tskIDLE_PRIORITY + 1,  /* initial priority */
      (xTaskHandle*)NULL /* optional task handle to create */
    ) != pdPASS) {
      /*lint -e527 */
      for(;;){}; /* error! probably out of memory */
      /*lint +e527 */
  }

  if (FRTOS1_xTaskCreate(
     RetiraDaFilaTask,  /* pointer to the task */
      "RetiraDaFila", /* task name for kernel awareness debugging */
      configMINIMAL_STACK_SIZE + 0, /* task stack size */
      (void*)NULL, /* optional task startup argument */
      tskIDLE_PRIORITY + 1,  /* initial priority */
      (xTaskHandle*)NULL /* optional task handle to create */
    ) != pdPASS) {
      /*lint -e527 */
      for(;;){}; /* error! probably out of memory */
      /*lint +e527 */
  }
}

