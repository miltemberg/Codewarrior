
#ifndef __frtos_tasks_H
#define __frtos_tasks_H

void CreateTasks(void);

#endif
