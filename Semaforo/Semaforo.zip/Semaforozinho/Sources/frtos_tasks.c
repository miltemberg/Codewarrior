
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/

/* Begin of <includes> initialization, DO NOT MODIFY LINES BELOW */

#include "TSK1.h"
#include "FRTOS1.h"
#include "frtos_tasks.h"

/* End <includes> initialization, DO NOT MODIFY LINES ABOVE */
#include "console_io.h"

SemaphoreHandle_t semaforo;

static portTASK_FUNCTION(EscreveTask, pvParameters) {
	int ValorAEnviar;
	BaseType_t xStatus;
	const int delay = 500/portTICK_RATE_MS;
	
	ValorAEnviar = (int)pvParameters;
	  /* Write your task initialization code here ... */
  for(;;) {
    /* Write your task code here ... */
	  vTaskDelay(delay);
	xStatus = FRTOS1_xSemaphoreTake(semaforo,delay);  
	if(xStatus == pdPASS){
		
		printf("%i\n", ValorAEnviar);
		FRTOS1_xSemaphoreGive(semaforo);
		
}  
    /* You can use a task delay like
       vTaskDelay(1000/portTICK_RATE_MS);
     */
  }
  /* Destroy the task */
  vTaskDelete(EscreveTask);
}

void CreateTasks(void) {
	semaforo= FRTOS1_xSemaphoreCreateBinary();
	FRTOS1_xSemaphoreGive(semaforo);
  if (FRTOS1_xTaskCreate(
     EscreveTask,  /* pointer to the task */
      "Escreve1", /* task name for kernel awareness debugging */
      configMINIMAL_STACK_SIZE + 0, /* task stack size */
      (void*)100, /* optional task startup argument */
      tskIDLE_PRIORITY + 1,  /* initial priority */
      (xTaskHandle*)NULL /* optional task handle to create */
    ) != pdPASS) {
      /*lint -e527 */
      for(;;){}; /* error! probably out of memory */
      /*lint +e527 */
  }
  if (FRTOS1_xTaskCreate(
       EscreveTask,  /* pointer to the task */
        "Escreve2", /* task name for kernel awareness debugging */
        configMINIMAL_STACK_SIZE + 0, /* task stack size */
        (void*)200, /* optional task startup argument */
        tskIDLE_PRIORITY + 1,  /* initial priority */
        (xTaskHandle*)NULL /* optional task handle to create */
      ) != pdPASS) {
        /*lint -e527 */
        for(;;){}; /* error! probably out of memory */
        /*lint +e527 */
    }
}

